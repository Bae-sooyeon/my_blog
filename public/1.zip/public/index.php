<?php
include "../part/head.php";
?>

<!-- 메뉴바 -->
<div class="logo-bar flex">

    <div class="logo flex flex-ai-c flex-1-0-0">
        <a class="flex" href="#">
            <img src="/resource/img/logo.png" alt="">
        </a>
    </div>

    <ul class="flex flex-grow-1 flex-jc-c  flex-ai-c">
        <li><a href="#">크라상점</a></li>
        <li><a href="#">메뉴안내</a></li>
        <li><a href="#">매장안내</a></li>
        <li><a href="#">창업안내</a></li>
        <li><a href="#">크라상점 뉴스</a></li>
    </ul>

    <div class="right-box flex flex-1-0-0 flex-jc-end">
        <ul class="flex-ai-c">
            <li>
                <a class="flex flex-ai-c" href="#"><img src="/resource/img/icon-1.png" alt=""></a>
            </li>
        </ul>
        <ul class="flex-ai-c">
            <li>
                <a class="flex flex-ai-c" href="#"><img src="/resource/img/icon-2.png" alt=""></a>
            </li>
        </ul>
        <ul class="flex-ai-c">
            <li>
                <a class="flex flex-ai-c" href="#"><img src="/resource/img/icon-3.png" alt=""></a>
            </li>
        </ul>
    </div>

</div>

<!-- 배너 이미지 -->

<div class="bn-img img-box">
    <img src="/resource/img/bn-img.jpg" alt="">
</div>


<!-- MENU 텍스트 -->
<div class="menu-text font-3">MENU</div>

<!-- 메뉴 박스 -->
<div class="prod-list-box">
    <ul class="con flex">
        <li class="flex">
            <div class="img-box">
                <img src="/resource/img/corn.png" alt="">
                <div class="prod-name">마약옥수수(Holic Corn)</div>
                <div class="prod-ex">한번 맛 보면 빠져나올 수 없는 '마약옥수수 크로와상'</div>
            </div>
        </li>
        <li class="flex">
            <div class="img-box">
                <img src="/resource/img/garlic_creamcheese.png" alt="">
                <div class="prod-name">마약옥수수(Holic Corn)</div>
                <div class="prod-ex">한번 맛 보면 빠져나올 수 없는 '마약옥수수 크로와상'</div>
            </div>
        </li>
        <li class="flex">
            <div class="img-box">
                <img src="/resource/img/strawberry_milk.png" alt="">
                <div class="prod-name">마약옥수수(Holic Corn)</div>
                <div class="prod-ex">한번 맛 보면 빠져나올 수 없는 '마약옥수수 크로와상'</div>
            </div>
        </li>
    </ul>
</div>

<!-- 메뉴 더보기 버튼 -->
<div class="menu-plus-btn con">메뉴 더보기</div>

<!-- 크라상점? 텍스트-->
<div class="text-box font-1">크라상점?</div>

<!-- 크라상점 설명-->
<div class="cr-ex-box flex bd-red">
    <ul class="flex flex-space-ar">
        <li>
            <div class="img-box">
                <img src="/resource/img/cr-1.png" alt="">
                <div class="cr-ex">크라상점은 크로와상 + 上(윗 상) + 店(가게 점) = '크로와상 중 가장 으뜸인 가게' 라는 의미를 담았습니다.</div>
            </div>
        </li>
        <li>
            <div class="img-box">
                <img src="/resource/img/cr-2.png" alt="">
                <div class="cr-ex">착한가격에 좋은 품질의 빵을 만들고자 다년간 연구해왔습니다.</div>
            </div>
        </li>
        <li>
            <div class="img-box">
                <img src="/resource/img/cr-3.png" alt="">
                <div class="cr-ex">남녀노소 누구나 부담없이 즐길 수 있는 빵이 있다는 것을 알리고 싶었습니다.</div>
            </div>
        </li>
        <li>
            <div class="img-box">
                <img src="/resource/img/cr-4.png" alt="">
                <div class="cr-ex">전문가가 아니어도 누구나 할 수 있는 손쉬운 방법을 찾고자 했습니다.</div>
            </div>
        </li>
        <li>
            <div class="img-box">
                <img src="/resource/img/cr-5.png" alt="">
                <div class="cr-ex">크라상점은 가격은 낮추고 품질은 높이고 다 같이 즐기기 위해 노력하고 있습니다.</div>
            </div>
        </li>
    </ul>
</div>



<?php
include "../part/foot.php";
?>